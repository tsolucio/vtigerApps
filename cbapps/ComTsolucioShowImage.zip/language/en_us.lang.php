<?php
$vtapps_strings = Array (
'appName' => 'Show Image',
'Title' => 'Show Image',
'TooltipDescription' => 'Show any image in a window!',
'imageurl'=>'Image URL:',
'saveurl'=>'Save URL',
'company'=>'Use company info',
'Edit' => 'Edit',

);

?>
