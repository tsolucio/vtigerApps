<?php
$vtapps_strings = Array (
'appName' => 'Mostrar Imagen',
'Title' => 'Mostrar Imagen',
'TooltipDescription' => 'Visualiza cualquier imagen en una ventana!',
'imageurl'=>'URL Imagen:',
'saveurl'=>'Guardar URL',
'company'=>'Utilizar información empresa',
'Edit' => 'Editar',

);

?>
