<?php
$vtapps_strings = Array (
'appName' => 'Cuadro Mando TSolucio',
'Title' => 'Cuadro Mando TSolucio',
'TooltipDescription' => 'Una forma alternativa de disponer las vtApps en el navegador.',
);

$vtapps_js_strings = Array (
);

?>
