<?php
$vtapps_strings = Array (
'appName' => 'TSolucio Dashboard',
'Title' => 'TSolucio Dashboard',
'TooltipDescription' => 'Different Dashboard Canvas to layout the vtApps',
);

$vtapps_js_strings = Array (
);

?>
