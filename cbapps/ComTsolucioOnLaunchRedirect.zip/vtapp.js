{
  onLaunch: function() {
	  document.location="index.php?module=evvtApps&action=index&evvtapps_canvas=dashboard";
	  return false;
  }
}