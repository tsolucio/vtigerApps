<?php
$vtapps_strings = Array (
'appName' => 'Quick TimeControl',
'Title' => 'Quick TimeControl',
'TooltipDescription' => 'vtApp to get the time you spend under control',
'Edit' => 'Edit',
'trackingtime'=>'You are currently working on',
'LBL_WATCH_STOP'=>'Stop',
'LBL_WATCH_RESTART'=>'Resume',
'LBL_WATCH_START'=>'Start',
'BillWith'=>'Bill with',
'Start'=>'Start',
'End'=>'End',
);

$vtapps_js_strings = Array (
	'LBL_WATCH_STOP'=>'Stop',
	'LBL_WATCH_RESTART'=>'Resume',
	'LBL_WATCH_START'=>'Start',
	'tcdate'=>'Date',
	'horainifin'=>'Time',
	'tctime'=>'Total',
	'tcrelto'=>'Related to',
	'tcbillw'=>'Bill with',
	'Continue'=>'Continue',
);

?>
