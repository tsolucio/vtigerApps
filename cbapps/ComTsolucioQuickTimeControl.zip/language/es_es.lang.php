<?php
$vtapps_strings = Array (
'appName' => 'Control Tiempo Rápido',
'Title' => 'Control Tiempo Rápido',
'TooltipDescription' => 'vtApp para poner tu tiempo bajo control',
'Edit' => 'Editar',
'trackingtime'=>'Estás trabajando en',
'LBL_WATCH_STOP'=>'Parar',
'LBL_WATCH_RESTART'=>'Continuar',
'LBL_WATCH_START'=>'Iniciar',
'BillWith'=>'Facturar con',
'Start'=>'Inicio',
'End'=>'Fin',

);

$vtapps_js_strings = Array (
	'LBL_WATCH_STOP'=>'Parar',
	'LBL_WATCH_RESTART'=>'Continuar',
	'LBL_WATCH_START'=>'Iniciar',
	'tcdate'=>'Fecha',
	'horainifin'=>'Tiempo',
	'tctime'=>'Total',
	'tcrelto'=>'Relacionado con',
	'tcbillw'=>'Facturar con',
	'Continue'=>'Continuar',
);

?>
