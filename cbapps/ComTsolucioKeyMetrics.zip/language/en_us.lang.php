<?php
$vtapps_strings = Array (
'appName' => 'Key Metrics Navigator',
'Title' => 'Key Metrics Navigator',
'TooltipDescription' => 'See and analyze your Key Metrics',
'Edit' => 'Edit',
'Save' => 'Save',
'Start Date:' => 'Start Date:',
'End Date:' => 'End Date:',
'Users:' => 'Users:',
'Total:' => 'Total:',
);

$vtapps_js_strings = Array (
);

?>
