<?php
$vtapps_strings = Array (
'appName' => 'Navegador de Métricas Clave',
'Title' => 'Navegador de Métricas Clave',
'TooltipDescription' => 'Ver y analizar tus Métricas Clave',
'Edit' => 'Editar',
'Save' => 'Guardar',
'Start Date:' => 'Fecha inicial:',
'End Date:' => 'Fecha final:',
'Users:' => 'Usuarios:',
'Total:' => 'Total:',
);

$vtapps_js_strings = Array (
);

?>
